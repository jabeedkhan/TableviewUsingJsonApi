//
//  UsageHistoryTableViewCell.swift
//  TableViewUsingApi
//
//  Created by jabeed on 27/09/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class UsageHistoryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var used_by: UILabel!
    @IBOutlet weak var deatils: UILabel!
    @IBOutlet weak var feedback: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
