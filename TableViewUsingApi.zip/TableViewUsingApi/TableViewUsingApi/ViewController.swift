//
//  ViewController.swift
//  TableViewUsingApi
//
//  Created by jabeed on 27/09/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit
//Model created
struct historyUsage {
    let date: String
    let used_by: String
    let deatils: String
    let feedback:String
}

struct productDetailsDictionary {
    let name: String
    let description: String
    let purchasedOn: String
    let historyArray: [historyUsage]
}

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var decrription: UILabel!
    @IBOutlet weak var purchased_on: UILabel!
    @IBOutlet weak var myTableView:UITableView!
    //var data = [sessions]()

    var productDetails:productDetailsDictionary?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.httpRequest()
    }
    
    func httpRequest() {
        
        //create the url with NSURL
        let url = URL(string: "http://demo9336585.mockable.io/portfolios")! //change the url
        
        //create the session object
        let session = URLSession.shared
        
        //now create the URLRequest object using the url object
        let request = URLRequest(url: url)
        
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            
            guard error == nil else {
                return
            }
            
            guard let data = data else {
                return
            }
            
            do {
                //create json object from data
                if let jsonDictionay = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    
                    var nameString:String?
                    if let nameStringValue = jsonDictionay["name"] as? String {
                        nameString = nameStringValue;
                    }
                    
                    var descriptionString:String?
                    
                    if let descriptionValue = jsonDictionay["description"] as? String {
                        descriptionString = descriptionValue
                    }
                    
                    var purchasedOnString:String?
                    if let purchasedOnValue = jsonDictionay["purchased on"] as? String {
                        purchasedOnString = purchasedOnValue;
                    }
                    
                    var usageHistoryArray: [historyUsage] = [];
                    if let usageHistoryValueAray = jsonDictionay["usage_history"] as? [[String:Any]] {
                        
                        for dictioanry in usageHistoryValueAray {
                            print(dictioanry)
                            var dateString:String?
                            var detailsString:String?
                            var feedbackString:String?
                            var usedByString:String?
                            if let dateValue = dictioanry["date"] as? String {
                                dateString = dateValue;
                            }
                            
                            if let detailsValue = dictioanry["details"] as? String {
                                detailsString = detailsValue;
                            }
                            
                            if let feedbackValue = dictioanry["feedback"] as? String {
                                feedbackString = feedbackValue;
                            }
                            
                            if let usedByValue = dictioanry["used_by"] as? String {
                                usedByString = usedByValue;
                            }
                            
                            
                            usageHistoryArray.append(historyUsage.init(date: dateString!, used_by: usedByString!, deatils: detailsString!, feedback: feedbackString!))
                            
                        }
                    }
                    
                    self.productDetails = productDetailsDictionary.init(name: nameString!, description: descriptionString!, purchasedOn: purchasedOnString!, historyArray: usageHistoryArray);
                    
                    print(self.productDetails!)
                    
                    DispatchQueue.main.async {
                        self.name.text = self.productDetails!.name;
                        self.decrription.text = self.productDetails!.description
                        self.purchased_on.text = self.productDetails!.purchasedOn
                    }
                    
                }
            } catch let error {
                print(error.localizedDescription)
            }
        })
        task.resume()
    }



}

